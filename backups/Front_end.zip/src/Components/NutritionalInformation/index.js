import React, { Component } from 'react';
import Select from 'react-select';
const options = [
    { value: 'chocolate', label: 'Chocolate' },
    { value: 'strawberry', label: 'Strawberry' },
    { value: 'vanilla', label: 'Vanilla' }
  ];
class NutritionalInformation extends Component {
    constructor(props){
        super(props)
        this.handleSelectChange = this.handleSelectChange.bind(this);
        this.state = {
            removeSelected: true,
			disabled: false,
            value:[],
            rtl: false,
        }
    }
    handleSelectChange = (value) => {
    
            this.setState({ value });
         
        
    }
    render() {
        const { value } = this.state;
        return ( <div className="col-xs-12 col-md-8 food_nutritional">
            <div className="nutri_info lightgray">
               <h3>Nutritional Information <span className="pull-right">% Daily Value*</span></h3>
               <div className="table-responsive">
                  <table className="table table-striped">
                     <tbody>
                        <tr>
                           <td>
                              <table className="table table-striped">
                                 <tbody>
                                    <tr>
                                       <td>Calories</td>
                                       <td>110</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Total Fat</td>
                                       <td>6g</td>
                                       <td>9%</td>
                                    </tr>
                                    <tr>
                                       <td>Trans Fat</td>
                                       <td>0g</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Protein</td>
                                       <td>2g</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Calcium</td>
                                       <td></td>
                                       <td>6%</td>
                                    </tr>
                                 </tbody>
                              </table>
                           </td>
                           <td>
                              <table className="table table-striped">
                                 <tbody>
                                    <tr>
                                       <td>Calories</td>
                                       <td>110</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Total Fat</td>
                                       <td>6g</td>
                                       <td>9%</td>
                                    </tr>
                                    <tr>
                                       <td>Trans Fat</td>
                                       <td>0g</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Protein</td>
                                       <td>2g</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Calcium</td>
                                       <td></td>
                                       <td>6%</td>
                                    </tr>
                                 </tbody>
                              </table>
                           </td>
                           <td>
                              <table className="table table-striped">
                                 <tbody>
                                    <tr>
                                       <td>Calories</td>
                                       <td>110</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Total Fat</td>
                                       <td>6g</td>
                                       <td>9%</td>
                                    </tr>
                                    <tr>
                                       <td>Trans Fat</td>
                                       <td>0g</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Protein</td>
                                       <td>2g</td>
                                       <td></td>
                                    </tr>
                                    <tr>
                                       <td>Calcium</td>
                                       <td></td>
                                       <td>6%</td>
                                    </tr>
                                 </tbody>
                              </table>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <p className="hint">*Percentage Daily Values are based on a 2,000 calorie diet. Your Daily Values may be higher or lower depending on your calorie needs:</p>
               <div className="table-responsive">
                  <table className="table table-striped">
                     <tbody>
                        <tr>
                           <td>
                              <table className="table table-striped">
                                 <tbody>
                                    <tr>
                                       <td></td>
                                       <td>Calories</td>
                                       <td>2000</td>
                                       <td>2,500</td>
                                    </tr>
                                    <tr>
                                       <td>Total Fat</td>
                                       <td>Less than</td>
                                       <td>65g</td>
                                       <td>85g</td>
                                    </tr>
                                    <tr>
                                       <td>Saturated Fat</td>
                                       <td>Less than</td>
                                       <td>20g</td>
                                       <td>25g</td>
                                    </tr>
                                    <tr>
                                       <td>Cholesterol</td>
                                       <td>Less than</td>
                                       <td>300mg</td>
                                       <td>300mg</td>
                                    </tr>
                                 </tbody>
                              </table>
                           </td>
                           <td>
                              <table className="table table-striped">
                                 <tbody>
                                    <tr>
                                       <td></td>
                                       <td>Calories</td>
                                       <td>2000</td>
                                       <td>2,500</td>
                                    </tr>
                                    <tr>
                                       <td>Sodium</td>
                                       <td>Less than</td>
                                       <td>2,400mg</td>
                                       <td>2,400mg</td>
                                    </tr>
                                    <tr>
                                       <td>Total Carbohydrate</td>
                                       <td></td>
                                       <td>300g</td>
                                       <td>375g</td>
                                    </tr>
                                    <tr>
                                       <td>Dietary Fibre</td>
                                       <td></td>
                                       <td>25mg</td>
                                       <td>30mg</td>
                                    </tr>
                                 </tbody>
                              </table>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <div className="table-responsive">
                  <table className="table table-striped cpg">
                     <tbody>
                        <tr>
                           <td>Calories per gram:</td>
                           <td>
                              <ul>
                                 <li>Fat 9</li>
                                 <li>Carbohydrate 4</li>
                                 <li>Protein 4</li>
                              </ul>
                           </td>
                        </tr>
                     </tbody>
                  </table>
               </div>
               <h3>Ingredients</h3>
               <div className="form-group">
                  <input type="text" className="type form-control" value="Milk, Sugar, Cream, Liquid Sugar, Corn Syrup, Whey, Vegetable Gums, Mono and Diglycerdices, Polysobrate" />
               </div>
               <h3>Allergens</h3>
               <div className="form-group">
                 
                  <Select id="status-select" options={options} clearable={true}  searchable={true}  placeholder={false}  value={value} 
                            onChange={this.handleSelectChange} multi />

               </div>
               <h3>Other Information</h3>
               <div className="otinfo_accr darkgryhead" id="otinfo_accr">
                  <div className="row">
                     <div className="col-xs-12 col-sm-6">
                        <div className="panel panel-default">
                           <div className="panel-heading">
                              <h4 className="panel-title">
                                 <a data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr1">
                                 Claims
                                 </a>
                              </h4>
                           </div>
                           <div id="otinfo_accr1" className="panel-collapse collapse">
                              1
                           </div>
                        </div>
                        <div className="panel panel-default">
                           <div className="panel-heading">
                              <h4 className="panel-title">
                                 <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr2">
                                 Certifications
                                 </a>
                              </h4>
                           </div>
                           <div id="otinfo_accr2" className="panel-collapse collapse">
                              2
                           </div>
                        </div>
                        <div className="panel panel-default">
                           <div className="panel-heading">
                              <h4 className="panel-title">
                                 <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr3">
                                 GMO Disclosure
                                 </a>
                              </h4>
                           </div>
                           <div id="otinfo_accr3" className="panel-collapse collapse">
                              3
                           </div>
                        </div>
                     </div>
                     <div className="col-xs-12 col-sm-6">
                        <div className="panel panel-default">
                           <div className="panel-heading">
                              <h4 className="panel-title">
                                 <a data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr4">
                                 Health &amp; Safety
                                 </a>
                              </h4>
                           </div>
                           <div id="otinfo_accr4" className="panel-collapse collapse">
                              1
                           </div>
                        </div>
                        <div className="panel panel-default">
                           <div className="panel-heading">
                              <h4 className="panel-title">
                                 <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr5">
                                 Product Instructions
                                 </a>
                              </h4>
                           </div>
                           <div id="otinfo_accr5" className="panel-collapse collapse">
                              2
                           </div>
                        </div>
                        <div className="panel panel-default">
                           <div className="panel-heading">
                              <h4 className="panel-title">
                                 <a className="collpased" data-toggle="collapse" data-parent="#otinfo_accr" href="#otinfo_accr6">
                                 Sustainability
                                 </a>
                              </h4>
                           </div>
                           <div id="otinfo_accr6" className="panel-collapse collapse">
                              3
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
        );
    }
}

export default NutritionalInformation;